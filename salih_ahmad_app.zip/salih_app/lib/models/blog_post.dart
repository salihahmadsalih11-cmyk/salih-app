class BlogPost {
  final String id;
  final String title;
  final String content;
  final String published;
  final String updated;
  final String? thumbnailUrl;
  final String? youtubeId;
  final List<String> labels;
  final String url;
  final String author;

  BlogPost({
    required this.id,
    required this.title,
    required this.content,
    required this.published,
    required this.updated,
    this.thumbnailUrl,
    this.youtubeId,
    required this.labels,
    required this.url,
    required this.author,
  });

  factory BlogPost.fromJson(Map<String, dynamic> json) {
    final String content = json['content']?['\$t'] ?? '';
    final String title = json['title']?['\$t'] ?? '';

    // Extract YouTube ID from content or links
    String? youtubeId = _extractYoutubeId(content);

    // Extract thumbnail
    String? thumbnail = _extractThumbnail(content, youtubeId);

    // Extract labels/categories
    List<String> labels = [];
    if (json['category'] != null) {
      for (var cat in json['category']) {
        if (cat['term'] != null) labels.add(cat['term']);
      }
    }

    // Extract URL
    String url = '';
    if (json['link'] != null) {
      for (var link in json['link']) {
        if (link['rel'] == 'alternate') {
          url = link['href'] ?? '';
          break;
        }
      }
    }

    // Author
    String author = json['author']?[0]?['name']?['\$t'] ?? 'م. صالح أحمد';

    // Published date
    String published = json['published']?['\$t'] ?? '';
    if (published.length >= 10) published = published.substring(0, 10);

    return BlogPost(
      id: json['id']?['\$t'] ?? '',
      title: title,
      content: content,
      published: published,
      updated: json['updated']?['\$t'] ?? '',
      thumbnailUrl: thumbnail,
      youtubeId: youtubeId,
      labels: labels,
      url: url,
      author: author,
    );
  }

  static String? _extractYoutubeId(String content) {
    final patterns = [
      RegExp(r'youtube\.com/embed/([a-zA-Z0-9_-]{11})'),
      RegExp(r'youtube\.com/watch\?v=([a-zA-Z0-9_-]{11})'),
      RegExp(r'youtu\.be/([a-zA-Z0-9_-]{11})'),
      RegExp(r'youtube\.com/v/([a-zA-Z0-9_-]{11})'),
    ];
    for (var pattern in patterns) {
      final match = pattern.firstMatch(content);
      if (match != null) return match.group(1);
    }
    return null;
  }

  static String? _extractThumbnail(String content, String? youtubeId) {
    if (youtubeId != null) {
      return 'https://img.youtube.com/vi/$youtubeId/mqdefault.jpg';
    }
    final imgPattern = RegExp(r'<img[^>]+src=["\']([^"\']+)["\']', caseSensitive: false);
    final match = imgPattern.firstMatch(content);
    if (match != null) return match.group(1);
    return null;
  }

  bool get hasVideo => youtubeId != null;
  bool get hasAudio => !hasVideo && content.toLowerCase().contains('soundcloud');

  String get formattedDate {
    try {
      final parts = published.split('-');
      if (parts.length >= 3) {
        final months = ['', 'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
          'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
        final month = int.tryParse(parts[1]) ?? 0;
        return '${parts[2]} ${months[month]} ${parts[0]}';
      }
    } catch (_) {}
    return published;
  }

  String get categoryLabel => labels.isNotEmpty ? labels.first : 'عام';
}
