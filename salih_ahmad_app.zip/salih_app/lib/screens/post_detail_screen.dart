import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import '../theme.dart';
import '../models/blog_post.dart';

class PostDetailScreen extends StatelessWidget {
  final BlogPost post;
  const PostDetailScreen({super.key, required this.post});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        backgroundColor: AppColors.bg,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded, color: AppColors.primary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(post.categoryLabel,
          style: const TextStyle(color: AppColors.textPrimary, fontSize: 14)),
        actions: [
          IconButton(
            icon: const Icon(Icons.share_outlined, color: AppColors.primary),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Labels
            if (post.labels.isNotEmpty)
              Wrap(
                spacing: 6, runSpacing: 6,
                children: post.labels.map((l) => Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                  decoration: BoxDecoration(
                    color: AppColors.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.primary.withOpacity(0.3)),
                  ),
                  child: Text(l, style: const TextStyle(
                    color: AppColors.primary, fontSize: 11)),
                )).toList(),
              ),
            const SizedBox(height: 12),
            // Title
            Text(post.title,
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontSize: 18,
                fontWeight: FontWeight.w600,
                height: 1.5,
              )),
            const SizedBox(height: 10),
            // Meta
            Row(
              children: [
                const Icon(Icons.person_outline_rounded,
                  color: AppColors.textMuted, size: 14),
                const SizedBox(width: 4),
                Text(post.author,
                  style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
                const SizedBox(width: 12),
                const Icon(Icons.calendar_today_outlined,
                  color: AppColors.textMuted, size: 12),
                const SizedBox(width: 4),
                Text(post.formattedDate,
                  style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
              ],
            ),
            const SizedBox(height: 16),
            Container(height: 0.5, color: AppColors.border),
            const SizedBox(height: 16),
            // Content
            Html(
              data: post.content,
              style: {
                'body': Style(
                  color: AppColors.textSecondary,
                  fontSize: FontSize(14),
                  lineHeight: const LineHeight(1.7),
                  margin: Margins.zero,
                  padding: HtmlPaddings.zero,
                ),
                'h1': Style(color: AppColors.textPrimary, fontSize: FontSize(18)),
                'h2': Style(color: AppColors.textPrimary, fontSize: FontSize(16)),
                'h3': Style(color: AppColors.textPrimary, fontSize: FontSize(15)),
                'a': Style(color: AppColors.primary),
                'strong': Style(color: AppColors.textPrimary),
                'p': Style(margin: Margins.only(bottom: 12)),
              },
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}
