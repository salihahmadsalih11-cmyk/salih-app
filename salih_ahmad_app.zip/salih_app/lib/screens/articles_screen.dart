import 'package:flutter/material.dart';
import '../theme.dart';
import '../models/blog_post.dart';
import '../services/blog_service.dart';
import 'post_detail_screen.dart';
import 'video_player_screen.dart';

class ArticlesScreen extends StatefulWidget {
  const ArticlesScreen({super.key});

  @override
  State<ArticlesScreen> createState() => _ArticlesScreenState();
}

class _ArticlesScreenState extends State<ArticlesScreen> {
  List<BlogPost> _posts = [];
  List<String> _labels = [];
  String? _selected;
  bool _loading = true;
  final TextEditingController _search = TextEditingController();
  String _query = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final posts = await BlogService().fetchPosts(maxResults: 50);
    final labels = await BlogService().fetchLabels();
    setState(() {
      _posts = posts;
      _labels = labels;
      _loading = false;
    });
  }

  List<BlogPost> get _filtered {
    var list = _posts;
    if (_selected != null) list = list.where((p) => p.labels.contains(_selected)).toList();
    if (_query.isNotEmpty) {
      list = list.where((p) =>
        p.title.toLowerCase().contains(_query.toLowerCase())).toList();
    }
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        backgroundColor: AppColors.bg,
        title: const Text('وتار · مقالات',
          style: TextStyle(color: AppColors.textPrimary, fontSize: 15)),
        automaticallyImplyLeading: false,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : Column(
              children: [
                // Search
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                  child: TextField(
                    controller: _search,
                    style: const TextStyle(color: AppColors.textPrimary, fontSize: 13),
                    decoration: InputDecoration(
                      hintText: 'گەڕان · بحث...',
                      hintStyle: const TextStyle(color: AppColors.textMuted, fontSize: 13),
                      prefixIcon: const Icon(Icons.search, color: AppColors.textMuted, size: 18),
                      filled: true,
                      fillColor: AppColors.bgCard,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(22),
                        borderSide: const BorderSide(color: AppColors.border),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(22),
                        borderSide: const BorderSide(color: AppColors.border),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(22),
                        borderSide: const BorderSide(color: AppColors.primary),
                      ),
                      contentPadding: const EdgeInsets.symmetric(vertical: 10),
                    ),
                    onChanged: (v) => setState(() => _query = v),
                  ),
                ),
                // Labels
                if (_labels.isNotEmpty)
                  SizedBox(
                    height: 38,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      children: [
                        _Chip(label: 'الكل', selected: _selected == null,
                          onTap: () => setState(() => _selected = null)),
                        ..._labels.map((l) => _Chip(
                          label: l,
                          selected: _selected == l,
                          onTap: () => setState(() =>
                            _selected = _selected == l ? null : l),
                        )),
                      ],
                    ),
                  ),
                const SizedBox(height: 8),
                Expanded(
                  child: RefreshIndicator(
                    color: AppColors.primary,
                    onRefresh: _load,
                    child: ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: _filtered.length,
                      itemBuilder: (ctx, i) {
                        final post = _filtered[i];
                        return _ArticleItem(
                          post: post,
                          onTap: () => Navigator.push(ctx, MaterialPageRoute(
                            builder: (_) => post.hasVideo
                              ? VideoPlayerScreen(post: post)
                              : PostDetailScreen(post: post))),
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _Chip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary : AppColors.bgCard,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: selected ? AppColors.primary : AppColors.border),
        ),
        child: Text(label, style: TextStyle(
          color: selected ? Colors.white : AppColors.textMuted, fontSize: 11)),
      ),
    );
  }
}

class _ArticleItem extends StatelessWidget {
  final BlogPost post;
  final VoidCallback onTap;
  const _ArticleItem({required this.post, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.bgCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            // Icon
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                color: AppColors.bgCard2,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColors.borderLight),
              ),
              child: Icon(
                post.hasVideo ? Icons.play_circle_outline_rounded
                    : Icons.article_outlined,
                color: AppColors.primary, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(post.title,
                    style: const TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 13, fontWeight: FontWeight.w500),
                    maxLines: 2, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      if (post.labels.isNotEmpty) ...[
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 7, vertical: 1),
                          decoration: BoxDecoration(
                            color: AppColors.primary.withOpacity(0.08),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(post.categoryLabel,
                            style: const TextStyle(
                              color: AppColors.primary, fontSize: 9)),
                        ),
                        const SizedBox(width: 8),
                      ],
                      Text(post.formattedDate,
                        style: const TextStyle(
                          color: AppColors.textMuted, fontSize: 10)),
                    ],
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded,
              color: AppColors.textMuted, size: 18),
          ],
        ),
      ),
    );
  }
}
