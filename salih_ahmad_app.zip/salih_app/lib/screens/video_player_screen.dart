import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import '../theme.dart';
import '../models/blog_post.dart';
import '../widgets/section_label.dart';
import '../services/blog_service.dart';
import 'video_player_screen.dart';

class VideoPlayerScreen extends StatefulWidget {
  final BlogPost post;
  const VideoPlayerScreen({super.key, required this.post});

  @override
  State<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen> {
  YoutubePlayerController? _controller;
  List<BlogPost> _related = [];
  bool _isFullScreen = false;

  @override
  void initState() {
    super.initState();
    if (widget.post.youtubeId != null) {
      _controller = YoutubePlayerController(
        initialVideoId: widget.post.youtubeId!,
        flags: const YoutubePlayerFlags(
          autoPlay: true,
          mute: false,
          enableCaption: false,
        ),
      );
    }
    _loadRelated();
  }

  Future<void> _loadRelated() async {
    final posts = await BlogService().fetchVideoPosts();
    setState(() {
      _related = posts.where((p) => p.id != widget.post.id).take(5).toList();
    });
  }

  @override
  void dispose() {
    _controller?.dispose();
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubePlayerBuilder(
      player: YoutubePlayer(
        controller: _controller!,
        showVideoProgressIndicator: true,
        progressIndicatorColor: AppColors.primary,
        progressColors: const ProgressBarColors(
          playedColor: AppColors.primary,
          handleColor: AppColors.primaryLight,
          bufferedColor: AppColors.border,
          backgroundColor: AppColors.bgCard,
        ),
        onEnded: (_) {},
      ),
      builder: (context, player) {
        return Scaffold(
          backgroundColor: AppColors.bg,
          appBar: _isFullScreen ? null : AppBar(
            backgroundColor: AppColors.bg,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios_rounded, color: AppColors.primary),
              onPressed: () => Navigator.pop(context),
            ),
            title: const Text('ڤیدیۆ · فيديو',
              style: TextStyle(color: AppColors.textPrimary, fontSize: 14)),
          ),
          body: Column(
            children: [
              // YouTube Player
              Container(
                color: Colors.black,
                child: widget.post.youtubeId != null
                    ? player
                    : Container(
                        height: 200,
                        color: AppColors.bgCard2,
                        child: const Center(
                          child: Icon(Icons.videocam_off_rounded,
                            color: AppColors.textMuted, size: 48),
                        ),
                      ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Title
                      Text(widget.post.title,
                        style: const TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          height: 1.5,
                        )),
                      const SizedBox(height: 8),
                      // Meta
                      Row(
                        children: [
                          const Icon(Icons.person_outline_rounded,
                            color: AppColors.textMuted, size: 14),
                          const SizedBox(width: 4),
                          Text(widget.post.author,
                            style: const TextStyle(
                              color: AppColors.textMuted, fontSize: 12)),
                          const SizedBox(width: 12),
                          const Icon(Icons.calendar_today_outlined,
                            color: AppColors.textMuted, size: 12),
                          const SizedBox(width: 4),
                          Text(widget.post.formattedDate,
                            style: const TextStyle(
                              color: AppColors.textMuted, fontSize: 12)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      // Labels
                      Wrap(
                        spacing: 6,
                        children: widget.post.labels.map((l) => Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 3),
                          decoration: BoxDecoration(
                            color: AppColors.primary.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: AppColors.primary.withOpacity(0.3)),
                          ),
                          child: Text(l, style: const TextStyle(
                            color: AppColors.primary, fontSize: 11)),
                        )).toList(),
                      ),
                      const SizedBox(height: 20),
                      // Related
                      if (_related.isNotEmpty) ...[
                        const SectionLabel(text: 'ڤیدیۆی مشابه · فيديوهات مشابهة'),
                        const SizedBox(height: 10),
                        ..._related.map((p) => _RelatedCard(
                          post: p,
                          onTap: () => Navigator.pushReplacement(context,
                            MaterialPageRoute(
                              builder: (_) => VideoPlayerScreen(post: p))),
                        )),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _RelatedCard extends StatelessWidget {
  final BlogPost post;
  final VoidCallback onTap;
  const _RelatedCard({required this.post, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: AppColors.bgCard,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            // Thumbnail
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Container(
                width: 80, height: 54,
                color: AppColors.bgCard2,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    if (post.thumbnailUrl != null)
                      Image.network(post.thumbnailUrl!, fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => const SizedBox()),
                    Center(
                      child: Container(
                        width: 24, height: 24,
                        decoration: BoxDecoration(
                          color: AppColors.primary.withOpacity(0.85),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.play_arrow_rounded,
                          color: Colors.white, size: 14),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(post.title,
                    style: const TextStyle(
                      color: AppColors.textSecondary,
                      fontSize: 12, fontWeight: FontWeight.w500),
                    maxLines: 2, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 4),
                  Text(post.formattedDate,
                    style: const TextStyle(
                      color: AppColors.textMuted, fontSize: 10)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
