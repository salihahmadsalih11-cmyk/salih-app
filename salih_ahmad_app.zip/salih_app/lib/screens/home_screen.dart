import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../theme.dart';
import '../models/blog_post.dart';
import '../services/blog_service.dart';
import '../widgets/post_card.dart';
import '../widgets/video_card.dart';
import '../widgets/section_label.dart';
import 'video_player_screen.dart';
import 'post_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<BlogPost> _posts = [];
  List<BlogPost> _videoPosts = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() { _loading = true; _error = null; });
    try {
      final posts = await BlogService().fetchPosts(maxResults: 30);
      final videos = posts.where((p) => p.hasVideo).toList();
      setState(() {
        _posts = posts;
        _videoPosts = videos;
        _loading = false;
      });
    } catch (e) {
      setState(() { _loading = false; _error = e.toString(); });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: RefreshIndicator(
        color: AppColors.primary,
        backgroundColor: AppColors.bgCard,
        onRefresh: _loadData,
        child: CustomScrollView(
          slivers: [
            _buildAppBar(),
            if (_loading)
              const SliverFillRemaining(child: Center(
                child: CircularProgressIndicator(color: AppColors.primary),
              ))
            else if (_error != null)
              SliverFillRemaining(child: _buildError())
            else ...[
              if (_videoPosts.isNotEmpty) _buildFeaturedVideo(),
              _buildSearchBar(),
              _buildHorizontalVideos(),
              _buildLatestPosts(),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return SliverAppBar(
      pinned: true,
      backgroundColor: AppColors.bg,
      elevation: 0,
      title: Row(
        children: [
          Container(
            width: 32, height: 32,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              gradient: const LinearGradient(
                colors: [AppColors.primary, AppColors.primaryDark],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: const Icon(Icons.home_rounded, color: Colors.white, size: 16),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(kAppName, style: const TextStyle(
                color: AppColors.textPrimary, fontSize: 14, fontWeight: FontWeight.w500)),
              Text(kAppSubtitle, style: const TextStyle(
                color: AppColors.textMuted, fontSize: 10)),
            ],
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: Stack(
            children: [
              const Icon(Icons.notifications_outlined, color: AppColors.primary),
              Positioned(
                top: 0, right: 0,
                child: Container(
                  width: 8, height: 8,
                  decoration: BoxDecoration(
                    color: AppColors.primary,
                    shape: BoxShape.circle,
                    border: Border.all(color: AppColors.bg, width: 1.5),
                  ),
                ),
              ),
            ],
          ),
          onPressed: () {},
        ),
      ],
    );
  }

  Widget _buildFeaturedVideo() {
    final post = _videoPosts.first;
    return SliverToBoxAdapter(
      child: GestureDetector(
        onTap: () => Navigator.push(context, MaterialPageRoute(
          builder: (_) => VideoPlayerScreen(post: post))),
        child: Container(
          height: 200,
          decoration: const BoxDecoration(color: AppColors.bgCard2),
          child: Stack(
            fit: StackFit.expand,
            children: [
              // Nebula background
              Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF07122A), Color(0xFF050D1A)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),
              // Thumbnail
              if (post.thumbnailUrl != null)
                Opacity(
                  opacity: 0.5,
                  child: CachedNetworkImage(
                    imageUrl: post.thumbnailUrl!,
                    fit: BoxFit.cover,
                  ),
                ),
              // Gradient overlay
              Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, AppColors.bg],
                    stops: [0.3, 1.0],
                  ),
                ),
              ),
              // Content
              Positioned(
                bottom: 0, left: 0, right: 0,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                        decoration: BoxDecoration(
                          color: AppColors.primary.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppColors.primary.withOpacity(0.4)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 6, height: 6,
                              decoration: const BoxDecoration(
                                color: AppColors.primary, shape: BoxShape.circle),
                            ),
                            const SizedBox(width: 5),
                            const Text('يُشاهد الآن · ئێستا دەبینرێت',
                              style: TextStyle(color: AppColors.primary, fontSize: 10)),
                          ],
                        ),
                      ),
                      const SizedBox(height: 7),
                      Text(post.title,
                        style: const TextStyle(
                          color: AppColors.textPrimary, fontSize: 14, fontWeight: FontWeight.w500),
                        maxLines: 2, overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Container(
                            width: 44, height: 44,
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: LinearGradient(
                                colors: [AppColors.primary, AppColors.primaryDark],
                              ),
                            ),
                            child: const Icon(Icons.play_arrow_rounded,
                              color: Colors.white, size: 22),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              children: [
                                LinearProgressIndicator(
                                  value: 0.28,
                                  backgroundColor: Colors.white.withOpacity(0.08),
                                  valueColor: const AlwaysStoppedAnimation(AppColors.primary),
                                  minHeight: 2.5,
                                  borderRadius: BorderRadius.circular(2),
                                ),
                                const SizedBox(height: 4),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(post.formattedDate,
                                      style: const TextStyle(
                                        color: AppColors.textMuted, fontSize: 9)),
                                    const Text('HD',
                                      style: TextStyle(
                                        color: AppColors.textMuted, fontSize: 9)),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          decoration: BoxDecoration(
            color: AppColors.bgCard,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            children: [
              const Icon(Icons.search, color: AppColors.textMuted, size: 16),
              const SizedBox(width: 8),
              const Expanded(
                child: Text('گەڕان · بحث في المحتوى...',
                  style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.primary.withOpacity(0.25)),
                ),
                child: Text('${_posts.length}+ بەش',
                  style: const TextStyle(color: AppColors.primary, fontSize: 10)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHorizontalVideos() {
    if (_videoPosts.isEmpty) return const SliverToBoxAdapter(child: SizedBox.shrink());
    return SliverToBoxAdapter(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 10),
            child: SectionLabel(text: 'زیاتر بكه‌ · استكشف'),
          ),
          SizedBox(
            height: 140,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _videoPosts.take(10).length,
              itemBuilder: (ctx, i) {
                final post = _videoPosts[i];
                return VideoCard(
                  post: post,
                  onTap: () => Navigator.push(ctx, MaterialPageRoute(
                    builder: (_) => VideoPlayerScreen(post: post))),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLatestPosts() {
    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (ctx, i) {
          if (i == 0) {
            return const Padding(
              padding: EdgeInsets.fromLTRB(16, 16, 16, 10),
              child: SectionLabel(text: 'تازەترین · أحدث المشاركات'),
            );
          }
          final post = _posts[i - 1];
          return PostCard(
            post: post,
            onTap: () {
              if (post.hasVideo) {
                Navigator.push(ctx, MaterialPageRoute(
                  builder: (_) => VideoPlayerScreen(post: post)));
              } else {
                Navigator.push(ctx, MaterialPageRoute(
                  builder: (_) => PostDetailScreen(post: post)));
              }
            },
          );
        },
        childCount: _posts.length + 1,
      ),
    );
  }

  Widget _buildError() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.wifi_off_rounded, color: AppColors.textMuted, size: 48),
          const SizedBox(height: 12),
          const Text('تعذّر الاتصال', style: TextStyle(color: AppColors.textSecondary)),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: _loadData,
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary),
            child: const Text('إعادة المحاولة'),
          ),
        ],
      ),
    );
  }
}
