import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../theme.dart';
import '../models/blog_post.dart';
import '../services/blog_service.dart';
import '../widgets/section_label.dart';
import 'video_player_screen.dart';

class VideosScreen extends StatefulWidget {
  const VideosScreen({super.key});

  @override
  State<VideosScreen> createState() => _VideosScreenState();
}

class _VideosScreenState extends State<VideosScreen> {
  List<BlogPost> _videos = [];
  List<String> _labels = [];
  String? _selectedLabel;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final videos = await BlogService().fetchVideoPosts();
    final labels = await BlogService().fetchLabels();
    setState(() {
      _videos = videos;
      _labels = labels;
      _loading = false;
    });
  }

  List<BlogPost> get _filtered {
    if (_selectedLabel == null) return _videos;
    return _videos.where((p) => p.labels.contains(_selectedLabel)).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        backgroundColor: AppColors.bg,
        title: const Text('ڤیدیۆ · فيديوهات',
          style: TextStyle(color: AppColors.textPrimary, fontSize: 15)),
        automaticallyImplyLeading: false,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : Column(
              children: [
                // Label filter
                if (_labels.isNotEmpty)
                  SizedBox(
                    height: 42,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      children: [
                        _FilterChip(label: 'الكل', selected: _selectedLabel == null,
                          onTap: () => setState(() => _selectedLabel = null)),
                        ..._labels.map((l) => _FilterChip(
                          label: l,
                          selected: _selectedLabel == l,
                          onTap: () => setState(() =>
                            _selectedLabel = _selectedLabel == l ? null : l),
                        )),
                      ],
                    ),
                  ),
                const SizedBox(height: 4),
                Expanded(
                  child: RefreshIndicator(
                    color: AppColors.primary,
                    onRefresh: _load,
                    child: ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: _filtered.length,
                      itemBuilder: (ctx, i) {
                        final post = _filtered[i];
                        return _VideoListItem(
                          post: post,
                          onTap: () => Navigator.push(ctx, MaterialPageRoute(
                            builder: (_) => VideoPlayerScreen(post: post))),
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _FilterChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary : AppColors.bgCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? AppColors.primary : AppColors.border),
        ),
        child: Text(label,
          style: TextStyle(
            color: selected ? Colors.white : AppColors.textMuted,
            fontSize: 12)),
      ),
    );
  }
}

class _VideoListItem extends StatelessWidget {
  final BlogPost post;
  final VoidCallback onTap;
  const _VideoListItem({required this.post, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: AppColors.bgCard,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Thumbnail
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
              child: AspectRatio(
                aspectRatio: 16 / 9,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Container(color: AppColors.bgCard2),
                    if (post.thumbnailUrl != null)
                      CachedNetworkImage(
                        imageUrl: post.thumbnailUrl!,
                        fit: BoxFit.cover,
                        errorWidget: (_, __, ___) => const SizedBox(),
                      ),
                    // Play overlay
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.transparent,
                            Colors.black.withOpacity(0.5)],
                        ),
                      ),
                    ),
                    Center(
                      child: Container(
                        width: 50, height: 50,
                        decoration: BoxDecoration(
                          color: AppColors.primary.withOpacity(0.9),
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.primary.withOpacity(0.4),
                              blurRadius: 20, spreadRadius: 2),
                          ],
                        ),
                        child: const Icon(Icons.play_arrow_rounded,
                          color: Colors.white, size: 28),
                      ),
                    ),
                    // Duration badge
                    Positioned(
                      bottom: 8, right: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.75),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: const Text('YouTube',
                          style: TextStyle(color: Colors.white, fontSize: 9)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Info
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(post.title,
                    style: const TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 13, fontWeight: FontWeight.w500),
                    maxLines: 2, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      const Icon(Icons.person_outline_rounded,
                        color: AppColors.textMuted, size: 12),
                      const SizedBox(width: 4),
                      Text(post.author,
                        style: const TextStyle(
                          color: AppColors.textMuted, fontSize: 11)),
                      const Spacer(),
                      Text(post.formattedDate,
                        style: const TextStyle(
                          color: AppColors.textMuted, fontSize: 11)),
                    ],
                  ),
                  if (post.labels.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppColors.primary.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: AppColors.primary.withOpacity(0.2)),
                      ),
                      child: Text(post.categoryLabel,
                        style: const TextStyle(
                          color: AppColors.primary, fontSize: 10)),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
