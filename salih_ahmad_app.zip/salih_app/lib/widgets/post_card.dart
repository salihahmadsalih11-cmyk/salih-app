import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../theme.dart';
import '../models/blog_post.dart';

class PostCard extends StatelessWidget {
  final BlogPost post;
  final VoidCallback onTap;
  const PostCard({super.key, required this.post, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.bgCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            // Thumbnail
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Container(
                width: 64, height: 64,
                color: AppColors.bgCard2,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    if (post.thumbnailUrl != null)
                      CachedNetworkImage(
                        imageUrl: post.thumbnailUrl!,
                        fit: BoxFit.cover,
                        errorWidget: (_, __, ___) => const SizedBox(),
                      ),
                    if (post.hasVideo)
                      Center(
                        child: Container(
                          width: 24, height: 24,
                          decoration: BoxDecoration(
                            color: AppColors.primary.withOpacity(0.85),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.play_arrow_rounded,
                            color: Colors.white, size: 14),
                        ),
                      ),
                    if (!post.hasVideo && post.thumbnailUrl == null)
                      Center(child: Icon(
                        Icons.article_outlined,
                        color: AppColors.primary.withOpacity(0.5), size: 24)),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(post.title,
                    style: const TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 13, fontWeight: FontWeight.w500, height: 1.4),
                    maxLines: 2, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 5),
                  Row(
                    children: [
                      if (post.labels.isNotEmpty) ...[
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 7, vertical: 1),
                          decoration: BoxDecoration(
                            color: AppColors.primary.withOpacity(0.08),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(
                              color: AppColors.primary.withOpacity(0.2)),
                          ),
                          child: Text(post.categoryLabel,
                            style: const TextStyle(
                              color: AppColors.primary, fontSize: 9)),
                        ),
                        const SizedBox(width: 8),
                      ],
                      Text(post.formattedDate,
                        style: const TextStyle(
                          color: AppColors.textMuted, fontSize: 10)),
                    ],
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded,
              color: AppColors.textMuted, size: 16),
          ],
        ),
      ),
    );
  }
}
