// widgets/section_label.dart
import 'package:flutter/material.dart';
import '../theme.dart';

class SectionLabel extends StatelessWidget {
  final String text;
  const SectionLabel({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(text, style: const TextStyle(
          color: AppColors.textMuted,
          fontSize: 10,
          letterSpacing: 0.8,
        )),
        const SizedBox(width: 8),
        Expanded(child: Container(height: 0.5, color: AppColors.border)),
      ],
    );
  }
}
