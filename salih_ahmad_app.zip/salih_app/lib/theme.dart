import 'package:flutter/material.dart';

class AppColors {
  // Sky Blue Dark Theme
  static const Color bg = Color(0xFF050D1A);
  static const Color bgCard = Color(0xFF090F1F);
  static const Color bgCard2 = Color(0xFF07122A);
  static const Color primary = Color(0xFF3290FF);
  static const Color primaryLight = Color(0xFF80D0FF);
  static const Color primaryDark = Color(0xFF0A50C0);
  static const Color border = Color(0xFF0E2040);
  static const Color borderLight = Color(0xFF1A3D70);
  static const Color textPrimary = Color(0xFFE8F4FF);
  static const Color textSecondary = Color(0xFFB8D8FF);
  static const Color textMuted = Color(0xFF1A4A7A);
  static const Color white = Colors.white;
}

class AppTheme {
  static ThemeData get dark => ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: AppColors.bg,
    primaryColor: AppColors.primary,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.primary,
      secondary: AppColors.primaryLight,
      surface: AppColors.bgCard,
      background: AppColors.bg,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.bg,
      elevation: 0,
      titleTextStyle: TextStyle(
        color: AppColors.textPrimary,
        fontSize: 16,
        fontWeight: FontWeight.w500,
      ),
      iconTheme: IconThemeData(color: AppColors.primary),
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: AppColors.bg,
      selectedItemColor: AppColors.primary,
      unselectedItemColor: AppColors.textMuted,
      type: BottomNavigationBarType.fixed,
      elevation: 0,
    ),
    textTheme: const TextTheme(
      bodyLarge: TextStyle(color: AppColors.textPrimary),
      bodyMedium: TextStyle(color: AppColors.textSecondary),
      bodySmall: TextStyle(color: AppColors.textMuted),
    ),
  );
}

const String kBlogUrl = 'https://salihahmadsalih.blogspot.com';
const String kBlogFeedUrl =
    'https://salihahmadsalih.blogspot.com/feeds/posts/default?alt=json&max-results=20';
const String kAppName = 'م. صالح أحمد';
const String kAppSubtitle = 'سایتی فەرمی';
