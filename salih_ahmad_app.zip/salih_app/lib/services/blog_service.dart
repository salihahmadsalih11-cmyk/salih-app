import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/blog_post.dart';
import '../theme.dart';

class BlogService {
  static final BlogService _instance = BlogService._internal();
  factory BlogService() => _instance;
  BlogService._internal();

  List<BlogPost> _cachedPosts = [];
  DateTime? _lastFetch;

  Future<List<BlogPost>> fetchPosts({
    int maxResults = 20,
    String? label,
    bool forceRefresh = false,
  }) async {
    // Cache for 10 minutes
    if (!forceRefresh &&
        _cachedPosts.isNotEmpty &&
        _lastFetch != null &&
        DateTime.now().difference(_lastFetch!).inMinutes < 10) {
      if (label == null) return _cachedPosts;
      return _cachedPosts.where((p) => p.labels.contains(label)).toList();
    }

    try {
      String url = '$kBlogFeedUrl&max-results=$maxResults';
      if (label != null) url += '&category=${Uri.encodeComponent(label)}';

      final response = await http.get(
        Uri.parse(url),
        headers: {'Accept': 'application/json'},
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final entries = data['feed']['entry'] as List? ?? [];
        _cachedPosts = entries.map((e) => BlogPost.fromJson(e)).toList();
        _lastFetch = DateTime.now();
        return _cachedPosts;
      }
    } catch (e) {
      // Return cached if available
      if (_cachedPosts.isNotEmpty) return _cachedPosts;
    }
    return [];
  }

  Future<List<BlogPost>> fetchVideoPosts() async {
    final all = await fetchPosts(maxResults: 50);
    return all.where((p) => p.hasVideo).toList();
  }

  Future<List<String>> fetchLabels() async {
    final posts = await fetchPosts(maxResults: 50);
    final Set<String> labels = {};
    for (var p in posts) {
      labels.addAll(p.labels);
    }
    return labels.toList();
  }
}
