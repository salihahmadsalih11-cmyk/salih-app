import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'theme.dart';
import 'screens/home_screen.dart';
import 'screens/videos_screen.dart';
import 'screens/articles_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));
  runApp(const SalihAhmadApp());
}

class SalihAhmadApp extends StatelessWidget {
  const SalihAhmadApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: kAppName,
      theme: AppTheme.dark,
      debugShowCheckedModeBanner: false,
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;

  final List<Widget> _screens = const [
    HomeScreen(),
    VideosScreen(),
    ArticlesScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: IndexedStack(index: _index, children: _screens),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          border: Border(
            top: BorderSide(color: AppColors.border, width: 0.5),
          ),
        ),
        child: BottomNavigationBar(
          currentIndex: _index,
          onTap: (i) => setState(() => _index = i),
          backgroundColor: AppColors.bg,
          selectedItemColor: AppColors.primary,
          unselectedItemColor: AppColors.textMuted,
          selectedLabelStyle: const TextStyle(fontSize: 10, fontWeight: FontWeight.w500),
          unselectedLabelStyle: const TextStyle(fontSize: 10),
          type: BottomNavigationBarType.fixed,
          elevation: 0,
          items: [
            BottomNavigationBarItem(
              icon: _NavIcon(icon: Icons.home_outlined, active: _index == 0),
              activeIcon: _NavIcon(icon: Icons.home_rounded, active: true, dot: true),
              label: 'سەرەكی',
            ),
            BottomNavigationBarItem(
              icon: _NavIcon(icon: Icons.play_circle_outline_rounded, active: _index == 1),
              activeIcon: _NavIcon(icon: Icons.play_circle_rounded, active: true, dot: true),
              label: 'ڤیدیۆ',
            ),
            BottomNavigationBarItem(
              icon: _NavIcon(icon: Icons.article_outlined, active: _index == 2),
              activeIcon: _NavIcon(icon: Icons.article_rounded, active: true, dot: true),
              label: 'وتار',
            ),
          ],
        ),
      ),
    );
  }
}

class _NavIcon extends StatelessWidget {
  final IconData icon;
  final bool active;
  final bool dot;
  const _NavIcon({required this.icon, required this.active, this.dot = false});

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Icon(icon),
        if (active && dot)
          Positioned(
            bottom: -4,
            left: 0, right: 0,
            child: Center(
              child: Container(
                width: 4, height: 4,
                decoration: const BoxDecoration(
                  color: AppColors.primary,
                  shape: BoxShape.circle,
                ),
              ),
            ),
          ),
      ],
    );
  }
}
