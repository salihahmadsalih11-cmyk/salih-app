# 📱 تطبيق م. صالح أحمد الرسمي
## سایتی فەرمی — Sky Blue Dark Edition

---

## 🗂️ هيكل المشروع

```
salih_ahmad_app/
├── lib/
│   ├── main.dart              ← نقطة البداية + Navigation
│   ├── theme.dart             ← الألوان والثيم
│   ├── models/
│   │   └── blog_post.dart     ← نموذج بيانات المقال
│   ├── services/
│   │   └── blog_service.dart  ← API مدونة Blogger
│   ├── screens/
│   │   ├── home_screen.dart         ← الصفحة الرئيسية
│   │   ├── videos_screen.dart       ← شاشة الفيديوهات
│   │   ├── articles_screen.dart     ← شاشة المقالات
│   │   ├── video_player_screen.dart ← مشغّل YouTube
│   │   └── post_detail_screen.dart  ← تفاصيل المقال
│   └── widgets/
│       ├── post_card.dart      ← بطاقة مقال
│       ├── video_card.dart     ← بطاقة فيديو أفقية
│       └── section_label.dart  ← عنوان القسم
├── android/
│   └── app/src/main/
│       └── AndroidManifest.xml ← صلاحيات الإنترنت
└── pubspec.yaml                ← المكتبات
```

---

## 🚀 خطوات التشغيل

### 1. تثبيت Flutter
```bash
# تحميل Flutter من:
https://flutter.dev/docs/get-started/install

# التحقق من التثبيت:
flutter doctor
```

### 2. تشغيل المشروع
```bash
cd salih_ahmad_app
flutter pub get
flutter run
```

### 3. بناء APK للأندرويد
```bash
flutter build apk --release
# الملف في: build/app/outputs/flutter-apk/app-release.apk
```

### 4. بناء للـ iOS
```bash
flutter build ios --release
# يحتاج Mac + Xcode
```

---

## ✨ المميزات

| الميزة | الوصف |
|--------|-------|
| 🎬 مشغّل YouTube | تشغيل فيديوهات YouTube مباشرة داخل التطبيق |
| 📰 مقالات | عرض مقالات المدونة بتنسيق HTML |
| 🔍 بحث | بحث في عناوين المقالات |
| 🏷️ فئات | تصفية حسب الأقسام |
| 🔄 تحديث تلقائي | سحب للتحديث + كاش 10 دقائق |
| 🌙 Dark Mode | ثيم داكن أزرق سماوي فاخر |
| 🌐 ثنائي اللغة | عربي + كردي |
| 📱 Android + iOS | كود واحد للمنصتين |

---

## 🎨 تغيير الألوان

في ملف `lib/theme.dart`:
```dart
static const Color primary = Color(0xFF3290FF);     // الأزرق الرئيسي
static const Color bg = Color(0xFF050D1A);           // خلفية داكنة
static const Color primaryLight = Color(0xFF80D0FF); // أزرق فاتح
```

---

## 🔗 تغيير رابط المدونة

في ملف `lib/theme.dart`:
```dart
const String kBlogUrl = 'https://salihahmadsalih.blogspot.com';
const String kBlogFeedUrl = 'https://salihahmadsalih.blogspot.com/feeds/posts/default?alt=json&max-results=20';
```

---

## 📦 المكتبات المستخدمة

| المكتبة | الغرض |
|---------|-------|
| `youtube_player_flutter` | تشغيل YouTube |
| `just_audio` | تشغيل صوتيات |
| `flutter_html` | عرض محتوى HTML |
| `cached_network_image` | تحميل الصور |
| `http` | طلبات API |
| `shared_preferences` | حفظ الإعدادات |

---

## 📤 النشر على Google Play

1. اذهب إلى `android/app/build.gradle` واضبط `versionCode` و `versionName`
2. أنشئ keystore: `keytool -genkey -v -keystore release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias key`
3. ابنِ الـ APK: `flutter build appbundle --release`
4. ارفع الملف على Google Play Console

---

بالتوفيق! 🎉
